// SocialBot Pro Application JavaScript

class SocialBotApp {
    constructor() {
        this.currentTab = 'dashboard';
        this.charts = {};
        this.init();
    }

    init() {
        this.initTabNavigation();
        this.initRangeSliders();
        this.initCostCalculator();
        this.initCharts();
        this.initCodeTabs();
        this.initImplementationRoadmap();
        this.initToggleControls();
        this.initButtonHandlers();
    }

    // Tab Navigation
    initTabNavigation() {
        const navTabs = document.querySelectorAll('.nav-tab');
        const tabContents = document.querySelectorAll('.tab-content');

        navTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const targetTab = tab.dataset.tab;
                this.switchTab(targetTab);
            });
        });
    }

    switchTab(targetTab) {
        // Update nav tabs
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-tab="${targetTab}"]`).classList.add('active');

        // Update tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(targetTab).classList.add('active');

        this.currentTab = targetTab;

        // Initialize charts when switching to relevant tabs
        if (targetTab === 'dashboard' || targetTab === 'monitoring') {
            setTimeout(() => this.initCharts(), 100);
        }
    }

    // Range Sliders
    initRangeSliders() {
        const sliders = document.querySelectorAll('.range-slider');
        
        sliders.forEach(slider => {
            // Set initial value display
            this.updateSliderValue(slider);
            
            slider.addEventListener('input', (e) => {
                this.updateSliderValue(e.target);
                
                // Special handling for cost calculator sliders
                if (e.target.id === 'postsSlider' || e.target.id === 'platformsSlider') {
                    this.updateCostCalculation();
                }
                
                if (e.target.id === 'postsPerDay') {
                    this.updatePostsPerDay(e.target.value);
                }
            });
        });
    }

    updateSliderValue(slider) {
        const valueSpan = document.getElementById(slider.id + 'Value') || 
                         document.querySelector(`[id="${slider.id.replace('Slider', 'Value')}"]`);
        if (valueSpan) {
            valueSpan.textContent = slider.value;
        }
    }

    updatePostsPerDay(value) {
        document.getElementById('postsPerDayValue').textContent = value;
    }

    // Cost Calculator
    initCostCalculator() {
        const postsSlider = document.getElementById('postsSlider');
        const platformsSlider = document.getElementById('platformsSlider');
        
        if (postsSlider && platformsSlider) {
            this.updateCostCalculation();
        }
    }

    updateCostCalculation() {
        const posts = parseInt(document.getElementById('postsSlider')?.value || 10);
        const platforms = parseInt(document.getElementById('platformsSlider')?.value || 2);
        
        // Calculate costs based on tiers
        let automationCost = 20;
        let aiCost = 100;
        let apiCost = 50;
        let moderationCost = 30;
        
        // Scale costs based on posts and platforms
        if (posts > 20) {
            automationCost = 200;
            aiCost = 800;
            apiCost = 300;
            moderationCost = 200;
        } else if (posts > 10) {
            automationCost = 50;
            aiCost = 300;
            apiCost = 100;
            moderationCost = 80;
        }

        // Add platform multiplier
        const platformMultiplier = Math.max(1, platforms / 2);
        apiCost = Math.round(apiCost * platformMultiplier);
        
        const total = automationCost + aiCost + apiCost + moderationCost;

        // Update display
        document.getElementById('automationCost').textContent = `$${automationCost}`;
        document.getElementById('aiCost').textContent = `$${aiCost}`;
        document.getElementById('apiCost').textContent = `$${apiCost}`;
        document.getElementById('moderationCost').textContent = `$${moderationCost}`;
        document.getElementById('totalCost').textContent = `$${total}`;
    }

    // Charts
    initCharts() {
        this.initPerformanceChart();
        this.initAnalyticsChart();
    }

    initPerformanceChart() {
        const ctx = document.getElementById('performanceChart');
        if (!ctx || this.charts.performance) return;

        this.charts.performance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Posts Published',
                    data: [12, 10, 14, 8, 13, 9, 11],
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Engagement Rate (%)',
                    data: [4.2, 3.8, 5.1, 3.5, 4.7, 3.2, 4.0],
                    borderColor: '#FFC185',
                    backgroundColor: 'rgba(255, 193, 133, 0.1)',
                    tension: 0.4,
                    fill: true,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Posts'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Engagement %'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    initAnalyticsChart() {
        const ctx = document.getElementById('analyticsChart');
        if (!ctx || this.charts.analytics) return;

        this.charts.analytics = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Instagram', 'LinkedIn', 'Facebook', 'Twitter'],
                datasets: [{
                    data: [45, 30, 15, 10],
                    backgroundColor: [
                        '#1FB8CD',
                        '#FFC185',
                        '#B4413C',
                        '#5D878F'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 15
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed}% of total engagement`;
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    }

    // Code Tabs
    initCodeTabs() {
        const codeTabs = document.querySelectorAll('.code-tab');
        const codeExample = document.getElementById('codeExample');

        if (!codeExample) return;

        const codeExamples = {
            javascript: `// Instagram Graph API - Post Image
const postToInstagram = async (imageUrl, caption) => {
  const response = await fetch(\`https://graph.facebook.com/v18.0/\${INSTAGRAM_ACCOUNT_ID}/media\`, {
    method: 'POST',
    body: JSON.stringify({
      image_url: imageUrl,
      caption: caption,
      access_token: ACCESS_TOKEN
    })
  });
  return response.json();
};

// LinkedIn Share API - Post Text
const postToLinkedIn = async (content) => {
  const response = await fetch('https://api.linkedin.com/v2/ugcPosts', {
    method: 'POST',
    headers: {
      'Authorization': \`Bearer \${LINKEDIN_TOKEN}\`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      author: \`urn:li:person:\${PERSON_ID}\`,
      lifecycleState: 'PUBLISHED',
      specificContent: {
        'com.linkedin.ugc.ShareContent': {
          shareCommentary: { text: content },
          shareMediaCategory: 'NONE'
        }
      }
    })
  });
  return response.json();
};`,
            python: `# Instagram Graph API - Post Image
import requests

def post_to_instagram(image_url, caption):
    url = f"https://graph.facebook.com/v18.0/{INSTAGRAM_ACCOUNT_ID}/media"
    payload = {
        'image_url': image_url,
        'caption': caption,
        'access_token': ACCESS_TOKEN
    }
    response = requests.post(url, data=payload)
    return response.json()

# LinkedIn Share API - Post Text  
def post_to_linkedin(content):
    url = "https://api.linkedin.com/v2/ugcPosts"
    headers = {
        'Authorization': f'Bearer {LINKEDIN_TOKEN}',
        'Content-Type': 'application/json'
    }
    payload = {
        'author': f'urn:li:person:{PERSON_ID}',
        'lifecycleState': 'PUBLISHED',
        'specificContent': {
            'com.linkedin.ugc.ShareContent': {
                'shareCommentary': {'text': content},
                'shareMediaCategory': 'NONE'
            }
        }
    }
    response = requests.post(url, headers=headers, json=payload)
    return response.json()`,
            curl: `# Instagram Graph API - Post Image
curl -X POST "https://graph.facebook.com/v18.0/${INSTAGRAM_ACCOUNT_ID}/media" \\
  -H "Content-Type: application/json" \\
  -d '{
    "image_url": "https://example.com/image.jpg",
    "caption": "Your caption here #hashtag",
    "access_token": "YOUR_ACCESS_TOKEN"
  }'

# LinkedIn Share API - Post Text
curl -X POST "https://api.linkedin.com/v2/ugcPosts" \\
  -H "Authorization: Bearer YOUR_LINKEDIN_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{
    "author": "urn:li:person:YOUR_PERSON_ID",
    "lifecycleState": "PUBLISHED",
    "specificContent": {
      "com.linkedin.ugc.ShareContent": {
        "shareCommentary": {"text": "Your post content here"},
        "shareMediaCategory": "NONE"
      }
    }
  }'`
        };

        codeTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                codeTabs.forEach(t => t.classList.remove('active'));
                // Add active class to clicked tab
                tab.classList.add('active');
                
                // Update code example
                const lang = tab.dataset.lang;
                if (codeExamples[lang]) {
                    codeExample.textContent = codeExamples[lang];
                }
            });
        });
    }

    // Implementation Roadmap
    initImplementationRoadmap() {
        const startBtn = document.getElementById('startImplementation');
        const downloadBtn = document.getElementById('downloadRoadmap');

        if (startBtn) {
            startBtn.addEventListener('click', () => {
                this.startImplementation();
            });
        }

        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => {
                this.downloadRoadmap();
            });
        }
    }

    startImplementation() {
        // Simulate starting implementation
        const progressBars = document.querySelectorAll('.progress-fill');
        const phases = [
            { element: progressBars[0], target: 25, duration: 1000 },
            { element: progressBars[1], target: 0, duration: 0 },
            { element: progressBars[2], target: 0, duration: 0 },
            { element: progressBars[3], target: 0, duration: 0 },
            { element: progressBars[4], target: 0, duration: 0 }
        ];

        // Start phase 1
        this.animateProgress(phases[0].element, phases[0].target, phases[0].duration);
        
        // Show success message
        this.showNotification('Implementation started! Phase 1 is now in progress.', 'success');
    }

    animateProgress(element, target, duration) {
        if (!element) return;
        
        let current = 0;
        const increment = target / (duration / 16); // 60fps
        
        const animate = () => {
            current += increment;
            if (current >= target) {
                current = target;
                element.style.width = `${current}%`;
                return;
            }
            element.style.width = `${current}%`;
            requestAnimationFrame(animate);
        };
        
        requestAnimationFrame(animate);
    }

    downloadRoadmap() {
        // Simulate downloading roadmap
        this.showNotification('Downloading detailed implementation roadmap...', 'info');
        
        // In a real app, this would download a PDF or CSV file
        setTimeout(() => {
            this.showNotification('Roadmap downloaded successfully!', 'success');
        }, 2000);
    }

    // Toggle Controls
    initToggleControls() {
        const toggles = document.querySelectorAll('.toggle');
        
        toggles.forEach(toggle => {
            toggle.addEventListener('change', (e) => {
                this.handleToggleChange(e.target);
            });
        });
    }

    handleToggleChange(toggle) {
        const label = toggle.parentElement.querySelector('label');
        const isChecked = toggle.checked;
        
        // Add visual feedback
        toggle.parentElement.style.opacity = isChecked ? '1' : '0.7';
        
        // In a real app, this would save the setting
        console.log(`Setting "${label.textContent}" changed to:`, isChecked);
    }

    // Button Handlers
    initButtonHandlers() {
        // Setup wizard continue button
        const continueSetupBtn = document.querySelector('.setup-wizard .btn--primary');
        if (continueSetupBtn) {
            continueSetupBtn.addEventListener('click', () => {
                this.continueSetup();
            });
        }

        // Pricing tier buttons
        const pricingButtons = document.querySelectorAll('.pricing-card .btn');
        pricingButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tier = e.target.closest('.pricing-card').querySelector('h3').textContent;
                this.selectPricingTier(tier);
            });
        });

        // API setup buttons
        const apiButtons = document.querySelectorAll('.api-card .btn--primary');
        apiButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const apiType = e.target.closest('.api-card').querySelector('h4').textContent;
                this.setupAPI(apiType);
            });
        });

        // Settings save button
        const saveConfigBtn = document.querySelector('.settings-actions .btn--primary');
        if (saveConfigBtn) {
            saveConfigBtn.addEventListener('click', () => {
                this.saveConfiguration();
            });
        }
    }

    continueSetup() {
        // Progress to next step
        const steps = document.querySelectorAll('.setup-step');
        const activeStep = document.querySelector('.setup-step.active');
        const currentIndex = Array.from(steps).indexOf(activeStep);
        
        if (currentIndex < steps.length - 1) {
            activeStep.classList.remove('active');
            activeStep.classList.add('completed');
            steps[currentIndex + 1].classList.add('active');
            
            this.showNotification('Setup step completed! Continue to the next step.', 'success');
        } else {
            this.showNotification('Setup completed! Your automation system is ready.', 'success');
        }
    }

    selectPricingTier(tier) {
        this.showNotification(`${tier} tier selected. Redirecting to checkout...`, 'info');
        
        // In a real app, this would redirect to payment processing
        setTimeout(() => {
            this.showNotification('Checkout process would begin here.', 'info');
        }, 1500);
    }

    setupAPI(apiType) {
        this.showNotification(`Setting up ${apiType}...`, 'info');
        
        // Simulate API setup process
        setTimeout(() => {
            this.showNotification(`${apiType} setup completed successfully!`, 'success');
            
            // Update status indicator
            const statusElement = document.querySelector(`.api-card h4:contains("${apiType}") + .status`);
            if (statusElement) {
                statusElement.className = 'status status--success';
                statusElement.textContent = 'Connected';
            }
        }, 2000);
    }

    saveConfiguration() {
        this.showNotification('Saving configuration...', 'info');
        
        // Collect form data
        const formData = {
            brandName: document.querySelector('input[value="SocialBot Pro"]')?.value,
            industry: document.querySelector('select')?.value,
            // Add more form fields as needed
        };
        
        // Simulate save operation
        setTimeout(() => {
            this.showNotification('Configuration saved successfully!', 'success');
        }, 1000);
    }

    // Utility Methods
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">${this.getNotificationIcon(type)}</span>
                <span class="notification-message">${message}</span>
            </div>
        `;

        // Add styles
        Object.assign(notification.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            background: type === 'success' ? '#1FB8CD' : type === 'error' ? '#B4413C' : '#5D878F',
            color: 'white',
            padding: '16px 20px',
            borderRadius: '8px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
            zIndex: '10000',
            transform: 'translateX(100%)',
            transition: 'transform 0.3s ease',
            maxWidth: '300px',
            fontSize: '14px'
        });

        notification.querySelector('.notification-content').style.display = 'flex';
        notification.querySelector('.notification-content').style.alignItems = 'center';
        notification.querySelector('.notification-content').style.gap = '8px';

        document.body.appendChild(notification);

        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);

        // Remove after delay
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 4000);
    }

    getNotificationIcon(type) {
        const icons = {
            success: '✓',
            error: '✕',
            warning: '⚠',
            info: 'ℹ'
        };
        return icons[type] || icons.info;
    }

    // Real-time updates simulation
    startRealTimeUpdates() {
        setInterval(() => {
            this.updateDashboardMetrics();
        }, 30000); // Update every 30 seconds
    }

    updateDashboardMetrics() {
        // Simulate real-time metric updates
        const metrics = document.querySelectorAll('.metric-value');
        if (metrics.length > 0) {
            // Update posts published
            const currentPosts = parseInt(metrics[0].textContent);
            if (currentPosts < 15) {
                metrics[0].textContent = currentPosts + 1;
            }

            // Update engagement rate (simulate fluctuation)
            const engagementRate = (Math.random() * (5.0 - 3.5) + 3.5).toFixed(1);
            if (metrics[1]) {
                metrics[1].textContent = engagementRate + '%';
            }

            // Update reach
            const currentReach = parseFloat(metrics[3].textContent.replace('K', ''));
            const newReach = (currentReach + (Math.random() * 0.2)).toFixed(1);
            if (metrics[3]) {
                metrics[3].textContent = newReach + 'K';
            }
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const app = new SocialBotApp();
    
    // Start real-time updates
    app.startRealTimeUpdates();
    
    // Make app globally accessible for debugging
    window.socialBotApp = app;
});

// Handle responsive navigation on mobile
window.addEventListener('resize', () => {
    if (window.innerWidth <= 768) {
        const navTabs = document.querySelector('.nav-tabs');
        if (navTabs) {
            navTabs.style.overflowX = 'auto';
        }
    }
});

// Add keyboard navigation support
document.addEventListener('keydown', (e) => {
    // Tab navigation with keyboard
    if (e.ctrlKey || e.metaKey) {
        const tabNumbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
        const tabNames = ['dashboard', 'architecture', 'content', 'workflows', 'pricing', 'implementation', 'api', 'monitoring', 'settings'];
        
        const index = tabNumbers.indexOf(e.key);
        if (index !== -1 && index < tabNames.length) {
            e.preventDefault();
            window.socialBotApp.switchTab(tabNames[index]);
        }
    }
});